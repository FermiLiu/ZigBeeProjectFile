#include <ioCC2530.h>

void main(void)
{     
  P1DIR |= 0xFF;  
  P1 = 0;
}