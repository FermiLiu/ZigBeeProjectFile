#ifndef BEEP_H
#define BEEP_H
#include"head.h"
extern void InitBeep(void);
extern void BeepOn(void);
extern void BeepOff(void);
#endif