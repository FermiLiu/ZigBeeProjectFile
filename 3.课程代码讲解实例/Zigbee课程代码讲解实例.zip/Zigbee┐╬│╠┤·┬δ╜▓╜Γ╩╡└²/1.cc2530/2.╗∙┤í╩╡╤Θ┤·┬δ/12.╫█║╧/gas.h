#ifndef GAS_HEAD_H
#define GAS_HEAD_H
#include "ioCC2530.h" 
#include "hal_types.h"
extern uint16 myApp_ReadGasLevel( void );
#endif

