#ifndef INFRARE_HEAD_H
#define INFRARE_HEAD_H
#include "ioCC2530.h" 
#include "hal_types.h"

#define HONGWAI P0_5 //定义P0.5口为红外控制�?

extern void Init_infrare(void);
#endif

