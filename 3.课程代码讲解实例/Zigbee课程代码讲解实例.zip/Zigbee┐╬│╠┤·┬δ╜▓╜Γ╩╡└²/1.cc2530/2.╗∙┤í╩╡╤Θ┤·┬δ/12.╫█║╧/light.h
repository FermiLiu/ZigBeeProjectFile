#ifndef LIGHT_H
#define LIGHT_H
#include "ioCC2530.h" 
#include "hal_types.h"

extern uint16 myApp_ReadLightLevel( void );
#endif

