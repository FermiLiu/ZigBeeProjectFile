/*
Nokia5110 ��msp430��Ƭ���ϵ�Ӧ��

08-12-08
*/
#include  <msp430x44x.h>
#include "nokia_5110.h"

/******************************************************************************/
void main(void) 
{
	WDTCTL = WDTPW + WDTHOLD;             // Stop watchdog timer

	LCD_init();                           //��ʼ��Һ��    
	LCD_clear();
        //P2DIR = 0xff;
	while(1)
	{
	        LCD_write_english_string(0,0,"Nokia5110 LCD");
                LCD_write_english_string(0,1,"www.nbdpj.com");
                
		LCD_write_chinese_string(12,2,12,4,0,5);        //���Գ���  
                LCD_write_chinese_string(0,4,12,7,4,0);         //������Ƭ������
	}	  
        
}
