
/*
������Ƭ��
pin   description
1     VCC(3.3V)
2     GND
3     CE
4     RST
5     DC
6     DIN
7     CLK
8     Vlcd(+5V)

*/
#ifndef __nokia_5110_h_
#define __nokia_5110_h_

#include "msp430x44x.h"

#define LCD_5110_DIR            P2DIR
#define LCD_5110_OUT		P2OUT

#define   LCD_RST    4
#define   LCD_CE    3
#define   LCD_DC    2
#define   LCD_DIN    1
#define   LCD_CLK    0

void LCD_init(void);
void LCD_clear(void);
void LCD_write_english_string(unsigned char X,unsigned char Y,char *s);
void LCD_write_chinese_string(unsigned char X, unsigned char Y,
                   unsigned char ch_with,unsigned char num,
                   unsigned char line,unsigned char row);
void LCD_write_char(unsigned char c);
void LCD_write_byte(unsigned char dat, unsigned char dc);
void delay_1us(void);                 

#endif
