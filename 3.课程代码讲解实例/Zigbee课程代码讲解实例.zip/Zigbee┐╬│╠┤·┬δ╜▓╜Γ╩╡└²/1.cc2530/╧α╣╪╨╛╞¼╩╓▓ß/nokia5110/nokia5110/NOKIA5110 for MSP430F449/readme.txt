
Nokia5110 LCD test

CPU:	msp430f449
by:	sharehej
data:	2008.12.08


pin   description	i/o
1     VCC(3.3V)		--
2     GND		--
3     CE		P2.3
4     RST		P2.4
5     DC		P2.2
6     DIN		P2.1
7     CLK		P2.0
8     Vlcd(+5V)		3~6V
