#include <string.h>
#include <stdio.h>
#include <stdlib.h>

#include "link_list.h"
//ע��ṹ��  linklist�Ķ����  linknode�Ķ���
// typedef struct _node_
// {
// 	link_datatype data;
// 	struct _node_ *next;
// }linknode, *linklist;
linklist envlinkHead,envlinkTail;

linklist CreateEmptyLinklist()
{
    linklist h;
    h = (linklist)malloc(sizeof(linknode));
    envlinkTail = h;
    h->next = NULL;
    return h;
}

int EmptyLinklist(linklist h)
{
    return NULL == h->next;
}

//��ȡ�ڵ�ֵ  ͬʱɾȥ�ڵ�  ��һ�ڵ�p
linklist GetLinknode(linklist h)
{
    if(1 == EmptyLinklist(h))
    {
        return NULL;
    }
    linklist p = h->next;
    h->next=p->next;
    if(p->next == NULL)
    {
        envlinkTail = h;

    }
    return p;
}

int InsertLinknode(link_datatype x)
{
    linklist q = (linklist)malloc(sizeof(linknode));
    if(q==NULL)
    {
        printf("InsertLinknodeERROR!\r\n");
        return -1;
    }

    envlinkTail->next = q;
    envlinkTail = q;
    q->data = x;
    q->next = NULL;
    //ʵ��ԭ��  ����һ�ڵ�q�Ŀռ�  ��ֵx���ڵ�q����  ԭ����
    //ԭ����  envlinkTail ���ָ��q  q = envlinkTail  ��β����Ϊq

    return 0;

}

linklist CreateEmptyCacheList()
{
    linklist h;
    h = (linklist)malloc(sizeof(linknode));
    h->next = NULL;
    return h;
}

linklist GetCacheNode (linklist h,linklist *t)
{
    if(1 == EmptyLinklist(h))
    {
        return NULL;
    }
    linklist p = h->next;
    h->next = p->next;
    if(p->next == NULL)
    {
        *t = h;
    }
    return p;
}

int InsertCacheNode(linklist *t,link_datatype x)
{
    linklist q = (linklist)malloc(sizeof(linknode));
    if(q == NULL)
    {
        printf("ERROR: InsertCacheNode\n");
        return -1;

    }
    (*t)->next = q;
    *t = q;
    q->data = x;
    q->next = NULL;

    return 0;

}
