#include <stdlib.h>
int main()
{
	printf("Using exit...\n");
	printf("This is the end");
	exit(0);
}
