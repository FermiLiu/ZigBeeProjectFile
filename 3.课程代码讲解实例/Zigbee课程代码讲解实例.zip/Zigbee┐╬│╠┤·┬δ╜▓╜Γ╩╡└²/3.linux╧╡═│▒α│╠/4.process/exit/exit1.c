#include <stdio.h>
#include <stdlib.h>

int main()
{
	printf("this process will exit!");
	exit(0);
	printf("never be displayed!");
}
