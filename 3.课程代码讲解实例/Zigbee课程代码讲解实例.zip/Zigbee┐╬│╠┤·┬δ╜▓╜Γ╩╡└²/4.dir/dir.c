#include <stdio.h>
#include <dirent.h>
#include <stdlib.h>
#include <string.h>


#define DIRNAME		"/www"
#define PHOTO_NUM_MAX		100

int main(int argc,void ** argv)
{
	DIR *dir;
	struct dirent *dirp;
	int total_num = 1;
	
	if(argc <=1)
	{
		printf("input dir\n");
		exit(0);
	}

	if((dir = opendir(argv[1])) == NULL)    //��ͼƬ��ŵ�Ŀ¼
	{
		perror("fail to opendir");
		exit(1);
	}
	
	while((dirp = readdir(dir)) != NULL)  //���ļ������ļ�������
	{
		if((strcmp(dirp->d_name,".")==0)||(strcmp(dirp->d_name,"..")==0))
		{
			continue;
		}
		printf( "type=%d %s\n",dirp->d_type,dirp->d_name);
		total_num++;
	}
	
	printf("\ntotal file number :%d\n",total_num);
	closedir(dir);
	
	return 0;
}
